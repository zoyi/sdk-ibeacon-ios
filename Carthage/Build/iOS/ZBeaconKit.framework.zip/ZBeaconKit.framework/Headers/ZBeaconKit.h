//
//  ZBeaconKit.h
//  ZBeaconKit
//
//  Created by Di Wu on 12/21/15.
//  Copyright © 2015 ZOYI. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ZBeaconKit.
FOUNDATION_EXPORT double ZBeaconKitVersionNumber;

//! Project version string for ZBeaconKit.
FOUNDATION_EXPORT const unsigned char ZBeaconKitVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ZBeaconKit/PublicHeader.h>


